package Exam1Ex1;

public class TestMicroOrdi {

	public static void main(String[] args) {
		MicroOrdi myMicroOrdi1 = new MicroOrdi("Intel 4", 16000,400,1500);
		MicroOrdi myMicroOrdi2 = new MicroOrdi("AMD", 32000,500,600);
		
		System.out.println("Les caracteristiques de l'ordinateur sont" + myMicroOrdi1);
		System.out.println("Les caracteristiques de l'ordinateur sont" + myMicroOrdi2);
		
		myMicroOrdi1.estCompatibleDualBootWinLux();
		myMicroOrdi1.estOkPourDevLinux();
		myMicroOrdi2.estCompatibleDualBootWinLux();
		myMicroOrdi2.estOkPourDevLinux();
}
}
