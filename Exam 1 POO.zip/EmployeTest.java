package Exam1Ex2;

public class EmployeTest {

	public static void main(String[] args) {
		Employe monEmploye1 = new Employe("Sauve","Guillaume");
		Employe monEmploye2 = new Employe("Johnson","Bobby");
		Employe monEmploye3 = new Employe("Vasquez","Fernando");
		Employe monEmploye4 = new Employe("Trudeau","Justin");
		monEmploye1.displayInfo();
		monEmploye2.displayInfo();
		monEmploye3.displayInfo();
		monEmploye4.displayInfo();
		// J'ai cr�er plus de 2 employ�s pour tester et aussi pour prouver que je ne fais pas de plagiat au cas o� d'autre �l�ves auraient les m�mes noms.
		

	}

}
