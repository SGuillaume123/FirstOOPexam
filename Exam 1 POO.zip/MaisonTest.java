package Exam1Ex3;

public class MaisonTest {

	public static void main(String[] args) {
	   Maison maMaison1 = new Maison("Duplex","721-723 Rue Walnut",1375000);
	   Maison maMaison2 = new Maison("Maison","35 Rue du Lievre",695000);
	   Maison maMaison3 = new Maison("Condo","109 Place du Soleil",895000);
	   Maison maMaison4 = new Maison("Chateau","123987 You Wish You Had A Real Castle",1);
	   System.out.println(maMaison1);
	   System.out.println(maMaison2);
	   System.out.println(maMaison3);
	   System.out.println(maMaison4);
	}

}
/* Voici les liens pour les maisons c'est des vraies addresses sauf pour la 4'
https://www.centris.ca/en/duplexes~for-sale~montreal-island
https://www.centris.ca/en/properties~for-sale~mercier?gclid=CjwKCAjwv-GUBhAzEiwASUMm4oQ95HqmV9PzLyf3ppz67Ea6LT24PuFhm9T3g8RFyloMfpTv4x6lkRoCgSEQAvD_BwE&uc=1
https://www.centris.ca/en/condos~for-sale~montreal-verdun-ile-des-soeurs?listingnotfound=12296407&gclid=CjwKCAjwv-GUBhAzEiwASUMm4h7vnMvQRvHlX46uz2AJvUhN9BKceQCI4sn8Me9sQzkjUhEkhOpnUhoCYBYQAvD_BwE&uc=2
*/