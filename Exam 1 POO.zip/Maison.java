package Exam1Ex3;

public class Maison {
	
	int ID = 0;
	private static int IDAutomatique = 1;
	String Type;
	String Adresse;
	double prix;
	
	public Maison(String type, String adresse, double prix) {
		super();
		Type = type;
		Adresse = adresse;
		this.prix = prix;
		ID = IDAutomatique;
		IDAutomatique++;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getAdresse() {
		return Adresse;
	}
	public void setAdresse(String adresse) {
		Adresse = adresse;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	@Override
	public String toString() {
		return "Maison [ID=" + ID + ", Type=" + Type + ", Adresse=" + Adresse + ", prix=" + prix + "$" + "]";
	}
	
	
}
