package Exam1Ex2;

public class Employe {
	
	private static int indexAutomatique = 1;
	private int matricule = 0;
	private int anciennete = 0;
	private String nom;
	private String prenom;
	
	public Employe(String nom, String prenom) {
		this.nom = nom;
		this.prenom = prenom;
		matricule = indexAutomatique;
		indexAutomatique++;
		anciennete++;
	}
	public static int getIndex()
	{
		return indexAutomatique;
	}
	public int getMatricule ()
	{
		return matricule;
	}
	protected void displayInfo() {
		System.out.println("Employe [matricule=" + matricule + ", anciennete=" + anciennete + ", nom=" + nom + ", prenom=" + prenom
				+ "]");
	}
	
}
