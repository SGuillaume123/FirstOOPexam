package Exam1Ex1;

public class MicroOrdi {
	
	private String processeur;
	private int ram;
	private int hd;
	private double prix;
	
	public MicroOrdi(String processeur, int ram, int hd, double prix) {
		super();
		this.processeur = processeur;
		this.ram = ram;
		this.hd = hd;
		this.prix = prix;
	}

	public String getProcesseur() {
		return processeur;
	}

	public void setProcesseur(String processeur) {
		this.processeur = processeur;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public int getHd() {
		return hd;
	}

	public void setHd(int hd) {
		this.hd = hd;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}
	
	@Override
	public String toString() {
		return "[processeur=" + processeur + ", ram=" + ram + ", hd=" + hd + ", prix=" + prix + "$" + "]";
	}

	public void estCompatibleDualBootWinLux() {
		// 8go ram 300 hd
		if (ram >=8000 && hd >= 300) {
			System.out.println("L'ordinateur peut supporter le dual boot. ");
		}
		else {
			System.out.println("L'ordinateur ne peut pas supporter le dual boot ");
		}
	}
	
	public void estOkPourDevLinux() {
		//8 go ram 500 hd
		if (ram >=8000 && hd >= 500) {
			System.out.println("L'ordinateur peut supporter le mode developpeur. ");
		}
		else {
			System.out.println("L'ordinateur ne peut pas supporter le mode developpeur. ");
		}
	}
}
	
	
	
	

